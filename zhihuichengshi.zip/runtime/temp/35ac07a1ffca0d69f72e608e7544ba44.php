<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:58:"D:\wwwroot\zhihuichengshi/city/staff\view\index\login.html";i:1491390207;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="__PUBLIC__/assets/css/font-awesome.min.css" />
        <!--[if IE 7]>
            <link rel="stylesheet" href="__PUBLIC__/assets/css/font-awesome-ie7.min.css" />
        <![endif]-->
        <link rel="stylesheet" href="__PUBLIC__/assets/css/ace.min.css" />
        <link rel="stylesheet" href="__PUBLIC__/assets/css/ace-rtl.min.css" />
        <link rel="stylesheet" href="__PUBLIC__/assets/css/ace-skins.min.css" />
        <link rel="stylesheet" href="__PUBLIC__/css/style.css" />
        <!--[if lte IE 8]>
            <link rel="stylesheet" href="__PUBLIC__/assets/css/ace-ie.min.css" />
        <![endif]-->
        <script src="__PUBLIC__/assets/js/ace-extra.min.js"></script>
        <!--[if lt IE 9]>
            <script src="__PUBLIC__/assets/js/html5shiv.js"></script>
            <script src="__PUBLIC__/assets/js/respond.min.js"></script>
        <![endif]-->
        <script src="__PUBLIC__/js/jquery-1.9.1.min.js"></script>
        <script src="__PUBLIC__/assets/layer/layer.js" type="text/javascript"></script>
        <title>房东管理系统</title>
	</head>
    <body class="login-layout">
        <div class="logintop">
			<span>房东管理系统</span>
        </div>
        <div class="loginbody">
            <div class="login-container">
                <div class="center">
                    <h1>
                        <i class="icon-leaf green"></i>
                        <span class="orange">智慧城市app</span>
                        <span class="white">房东管理系统</span>
					</h1>
				</div>
                <div class="space-6"></div>
                <div class="position-relative">
                    <div id="login-box" class="login-box widget-box no-border visible">
                        <div class="widget-body">
                            <div class="widget-main">
                                <h4 class="header blue lighter bigger"><i class="icon-coffee green"></i>房东登陆</h4>
                                <div class="login_icon"><img src="__PUBLIC__/images/login.png" /></div>
                                <form class="" id="form" onsubmit="return do_login(this);">
                                    <fieldset>
                                        <label class="block clearfix">
                                            <span class="block input-icon input-icon-right">
                                                <input type="text" class="form-control" placeholder="用户名" name="username">
                                                <i class="icon-user"></i>
                                            </span>
                                        </label>
                                        <label class="block clearfix">
                                            <span class="block input-icon input-icon-right">
                                                <input type="password" class="form-control" placeholder="密码" name="password">
                                                <i class="icon-lock"></i>
                                            </span>
                                        </label>
                                        <div class="space"></div>
                                        <div class="clearfix">
                                            <button type="submit" class="width-35 pull-left btn btn-sm btn-primary"><i class="icon-key"></i>登陆</button>
                                        </div>
                                        <div class="space-4"></div>
                                    </fieldset>
                                </form>
                                <div class="social-or-login center">
                                    <span class="bigger-110">提示</span>
								</div>
                                <div class="social-login center">本网站系统不再对IE8以下浏览器支持，请见谅。</div>
							</div>
                            <div class="toolbar clearfix"></div>
                        </div>
					</div>
				</div>
			</div>
        </div>
        <div class="loginbm">版权所有 2017<a href="">智慧城市</a></div>
    </body>
</html>
<script>
function do_login(_this){
    var str = "";
    $("input[type$='text']").each(function(n){
        if ($(this).val()== "") {
            layer.alert(str += "" + $(this).attr("placeholder") + "不能为空！\r\n", {
                title: '提示框',
                icon: 0,
            });
            return false;
        }
    });
    if(str){
        return false;;
    }
    var data = $(_this).serialize();
    $.post('',data,function(res){
        var index = layer.alert(res.msg, {
            title: '提示框',
            icon: res.code,
            yes:function(){
                layer.close(index);
                if(res.code==1){
                    window.location.href="<?php echo url('index'); ?>";
                }
            }
        });
    });

    return false;
};
$('#login_btn').on('click',function() {
	var str = "";
	$("input[type$='text']").each(function(n){
		if ($(this).val()== "") {
			layer.alert(str += "" + $(this).attr("placeholder") + "不能为空！\r\n", {
				title: '提示框',
				icon: 0,
			});
			return false;
		}
	});
    if(str){
        return;
    }
	var data = $("#form").serialize();
	$.post('',data,function(res){
		var index = layer.alert(res.msg, {
            title: '提示框',
            icon: res.code,
            yes:function(){
                layer.close(index);
                if(res.code==1){
                    window.location.href="<?php echo url('index'); ?>";
                }
            }
        });
	});
})
</script>