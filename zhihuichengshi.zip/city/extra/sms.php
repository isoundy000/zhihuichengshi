<?php
return array('username'=>'codeerror','password'=>'yksy888','sign'=>'一二网络',);